<script setup>
import { ref } from 'vue'
import axios from 'axios'

// 表单相关的响应式数据
const name = ref('')
const studentId = ref('')
const isProcessing = ref(false)
const message = ref('')
const messageType = ref('') // success, error, info

// 添加水印并下载PDF
const addWatermarkAndDownload = async () => {
  // 表单验证
  if (!name.value.trim()) {
    showMessage('请输入姓名', 'error')
    return
  }
  
  if (!studentId.value.trim()) {
    showMessage('请输入学号', 'error')
    return
  }
  
  // 验证学号必须为12位数字
  const studentIdRegex = /^\d{12}$/
  if (!studentIdRegex.test(studentId.value.trim())) {
    showMessage('学号必须为12位数字', 'error')
    return
  }
  
  isProcessing.value = true
  showMessage('正在处理文件，请稍候...', 'info')
  
  try {
    // 创建FormData对象
    const formData = new FormData()
    formData.append('name', name.value.trim())
    formData.append('studentId', studentId.value.trim())
    
    // 发送请求到后端
    const response = await axios.post('http://localhost:5000/api/add-watermark', 
      formData, 
      {
        responseType: 'blob', // 重要，确保返回二进制数据
        headers: {
          'Content-Type': 'multipart/form-data'
        },
        timeout: 300000 // 设置较长的超时时间（5分钟）
      }
    )
    
    // 创建下载链接并触发下载
    const url = window.URL.createObjectURL(new Blob([response.data]))
    const link = document.createElement('a')
    link.href = url
    
    // 设置下载的文件名
    const timestamp = new Date().getTime()
    link.setAttribute('download', `实验报告纸_${name.value.trim()}_${studentId.value.trim()}_${timestamp}_已添加水印.pdf`)
    
    // 隐藏链接并点击
    document.body.appendChild(link)
    link.click()
    
    // 清理
    document.body.removeChild(link)
    window.URL.revokeObjectURL(url)
    
    showMessage('PDF水印添加成功，文件已开始下载', 'success')
    
  } catch (error) {
    console.error('添加水印失败:', error)
    let errorMessage = '处理文件时发生错误'
    if (error.response?.data?.message) {
      errorMessage = error.response.data.message
    } else if (error.message) {
      errorMessage = error.message
    }
    showMessage(errorMessage, 'error')
  } finally {
    isProcessing.value = false
  }
}

// 显示消息
const showMessage = (msg, type = 'info') => {
  message.value = msg
  messageType.value = type
  
  // 3秒后自动清除消息
  setTimeout(() => {
    if (type !== 'error') {
      message.value = ''
      messageType.value = ''
    }
  }, 3000)
}
</script>

<template>
  <div class="app-container">
    <header class="app-header">
      <h1>烟台大学物理实验中心</h1>
    </header>
    
    <main class="app-main">
      <div class="form-container">
        <div class="form-group">
          <label for="name">姓名</label>
          <input
            id="name"
            v-model="name"
            type="text"
            placeholder="请输入您的姓名"
            :disabled="isProcessing"
          />
        </div>
        
        <div class="form-group">
          <label for="studentId">学号</label>
          <input
            id="studentId"
            v-model="studentId"
            type="text"
            placeholder="请输入您的学号"
            :disabled="isProcessing"
          />
        </div>
        
        <div class="form-group">
          <div class="file-info">
            <p>系统将自动使用根目录下的<span class="highlight">实验报告纸.pdf</span></p>
          </div>
        </div>
        
        <button 
          class="submit-button"
          @click="addWatermarkAndDownload"
          :disabled="isProcessing"
        >
          <span v-if="isProcessing" class="loading-spinner"></span>
          {{ isProcessing ? '处理中...' : '添加水印并下载' }}
        </button>
      </div>
      
      <!-- 消息提示 -->
      <div v-if="message" :class="['message', messageType]">
        {{ message }}
      </div>
    </main>
    
    <footer class="app-footer">
      <p>© 2024 PDF水印添加工具 - 保护您的文档版权</p>
    </footer>
  </div>
</template>

<style>
/* 全局样式重置 */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  line-height: 1.6;
  color: #333;
  background-color: #f5f5f5;
}

/* 应用容器 */
.app-container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* 头部样式 */
.app-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  text-align: center;
  padding: 2rem 1rem;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.app-header h1 {
  font-size: 2.5rem;
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.app-header p {
  font-size: 1.1rem;
  opacity: 0.9;
}

/* 主要内容区域 */
.app-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 2rem 1rem;
  max-width: 600px;
  margin: 0 auto;
  width: 100%;
}

/* 表单容器 */
.form-container {
  background: white;
  border-radius: 12px;
  padding: 2rem;
  width: 100%;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

/* 表单组样式 */
.form-group {
  margin-bottom: 1.5rem;
}

.form-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-weight: 500;
  color: #555;
}

.form-group input[type="text"] {
  width: 100%;
  padding: 0.75rem 1rem;
  border: 2px solid #e1e5e9;
  border-radius: 8px;
  font-size: 1rem;
  transition: border-color 0.3s ease;
}

.form-group input[type="text"]:focus {
  outline: none;
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.form-group input[type="text"]:disabled {
  background-color: #f8f9fa;
  cursor: not-allowed;
}

/* 文件信息样式 */
.file-info {
  padding: 1.5rem;
  background-color: #f8f9ff;
  border-radius: 8px;
  border: 1px solid #e1e5e9;
  text-align: center;
}

.file-info p {
  color: #666;
  margin: 0;
}

.highlight {
  color: #667eea;
  font-weight: 600;
}

/* 提交按钮样式 */
.submit-button {
  width: 100%;
  padding: 0.75rem 1rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 1.1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
}

.submit-button:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.submit-button:disabled {
  opacity: 0.7;
  cursor: not-allowed;
  transform: none;
}

/* 加载动画 */
.loading-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-top: 2px solid white;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* 消息提示样式 */
.message {
  margin-top: 1rem;
  padding: 0.75rem 1rem;
  border-radius: 8px;
  font-weight: 500;
  text-align: center;
  animation: slideIn 0.3s ease;
}

.message.success {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.message.error {
  background-color: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}

.message.info {
  background-color: #d1ecf1;
  color: #0c5460;
  border: 1px solid #bee5eb;
}

@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 页脚样式 */
.app-footer {
  background-color: #f8f9fa;
  text-align: center;
  padding: 1rem;
  color: #6c757d;
  border-top: 1px solid #dee2e6;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .app-header h1 {
    font-size: 2rem;
  }
  
  .form-container {
    padding: 1.5rem;
  }
  
  .file-upload {
    padding: 1.5rem;
  }
}
</style>
